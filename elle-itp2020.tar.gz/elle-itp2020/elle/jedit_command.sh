#!/bin/bash
isabelle jedit -d ../lem -d . -l ElleCorrect
