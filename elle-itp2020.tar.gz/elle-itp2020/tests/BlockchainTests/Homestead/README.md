Rules for .json tests execution in this folder: 

All blocks starting from #0 are on Homestead rules
No Dao Transition rules applied
