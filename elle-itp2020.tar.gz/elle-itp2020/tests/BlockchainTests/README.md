The tests .json files in this folder are to be executed with frontier rules from block 0.
