Rules for .json tests execution in this folder: 

block #0 - 4:  Frontier Rules  
block #5: Transition Block to Homestead  
block #8: Dao Hardfork block  
block #10: Transition Block to EIP150  
