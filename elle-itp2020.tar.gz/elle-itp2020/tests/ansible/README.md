# Automatic deployment of the random test generator

Testing is done in a Vagrant virtual machine

install vagrant, virtualbox, ansible, then do `vagrant up`. It should provison a basic machine. `vagrant ssh` to verify the machine is working as expected. `vagrant terminate` to reset machine to clean state.
