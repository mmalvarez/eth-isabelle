#/bin/sh

export LEMDIR=/usr/local/share/lem
$LEMDIR/lem $*
