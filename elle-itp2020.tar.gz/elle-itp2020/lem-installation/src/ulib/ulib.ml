module UChar = BatUChar
module UTF8 = BatUTF8
module Text = BatText
