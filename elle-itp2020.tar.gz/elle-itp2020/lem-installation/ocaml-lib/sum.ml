type ('a, 'b) sum  = 
  | Inl of 'a
  | Inr of 'b

