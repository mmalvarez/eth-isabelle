## HTML

The command line option `-html` instructs Lem to generate HTML output. A module with name `Mymodule` generates a file `Mymodule.html`. No auxiliary files are generated. 

