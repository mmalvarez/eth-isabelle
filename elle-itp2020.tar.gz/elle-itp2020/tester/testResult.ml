type testResult = TestSuccess | TestSkipped | TestFailure
