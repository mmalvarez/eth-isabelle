export ISABELLE_HOME=/home/yh/infra-src/Isabelle2016-1
$ISABELLE_HOME/bin/isabelle build -d . deed
