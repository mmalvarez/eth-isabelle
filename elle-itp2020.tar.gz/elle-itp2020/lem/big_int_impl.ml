module BI = struct
  include Big_int_Z
  include Z
end
